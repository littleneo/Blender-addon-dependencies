#
# load me in a text block (don't change its name !)
# then alt-P, this only creates "CRC" text block
# nothing is written/created except this
#

import os
from zlib import crc32
import bpy

modded = [
    'modules/addon_utils.py',
    'startup/bl_operators/wm.py',
    'startup/bl_ui/space_userpref.py'
 ]
 
test_path = os.path.dirname(bpy.data.texts['test_me_please.py'].filepath) + '/mods/'
bp_path = bpy.utils.script_paths()[0] + '/'

res = 'from : ???\nsystem : %s\nversion :%s (%s)\n'%(bpy.app.build_platform,bpy.app.version,bpy.app.build_revision)
res += '\n  modded :\n'
for file_path in modded :
    filename = file_path.split('/')[-1]
    fb = open(test_path + filename,'rb')
    crc = format( crc32(fb.read()) & 0xFFFFFFFF, '08x')
    fb.close()
    res += '    %s %s\n'%(crc,filename)

res += '\n  running :\n'
for file_path in modded :
    filename = file_path.split('/')[-1]
    fb = open(bp_path + file_path,'rb')
    crc = format( crc32(fb.read()) & 0xFFFFFFFF, '08x')
    fb.close()
    res += '    %s %s\n'%(crc,filename)

crc = bpy.data.texts.new(name='CRC')
crc.write(res)
print('done.\nresults are in the "CRC" text block please share it with me.\nthanks blender geek :)')

